<?php
require_once __DIR__ . '/config/db_connect.php';
try {
    $count = $pdo->query("SELECT COUNT(*) FROM ip_whitelist")->fetchColumn();
    echo "Whitelist count: " . $count . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
