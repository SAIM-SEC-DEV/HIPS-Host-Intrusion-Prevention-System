<?php
$currentPage = 'dashboard';
require_once 'includes/session.php';

// ── Fetch dashboard statistics ───────────────────────────────
$totalAgents   = (int) $pdo->query("SELECT COUNT(*) FROM agents")->fetchColumn();
$onlineAgents  = (int) $pdo->query("SELECT COUNT(*) FROM agents WHERE status = 'online'")->fetchColumn();
$offlineAgents = $totalAgents - $onlineAgents;
$activeAlerts  = (int) $pdo->query("SELECT COUNT(*) FROM alerts WHERE status = 'new'")->fetchColumn();
$fileEvents    = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'file' AND DATE(created_at) = CURDATE()")->fetchColumn();
$networkEvents = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'network' AND DATE(created_at) = CURDATE()")->fetchColumn();
$processEvents = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'process' AND DATE(created_at) = CURDATE()")->fetchColumn();
$registryEvents= (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'registry' AND DATE(created_at) = CURDATE()")->fetchColumn();
$memoryEvents  = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'memory' AND DATE(created_at) = CURDATE()")->fetchColumn();
$assetEvents   = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module = 'asset' AND DATE(created_at) = CURDATE()")->fetchColumn();
$commandsSent  = (int) $pdo->query("SELECT COUNT(*) FROM commands WHERE DATE(issued_at) = CURDATE()")->fetchColumn();
$totalEvents   = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE DATE(created_at) = CURDATE()")->fetchColumn();

// Severity counts for threat gauge
$criticalCount = (int)$pdo->query("SELECT COUNT(*) FROM alerts WHERE severity='CRITICAL' AND status='new'")->fetchColumn();
$highCount     = (int)$pdo->query("SELECT COUNT(*) FROM alerts WHERE severity='HIGH' AND status='new'")->fetchColumn();
$medCount      = (int)$pdo->query("SELECT COUNT(*) FROM alerts WHERE severity='MEDIUM' AND status='new'")->fetchColumn();

// Threat score (0-100)
$threatScore = min(100, $criticalCount * 25 + $highCount * 10 + $medCount * 3);
$threatLevel = $threatScore >= 70 ? 'CRITICAL' : ($threatScore >= 40 ? 'HIGH' : ($threatScore >= 15 ? 'MEDIUM' : 'LOW'));
$threatColor = $threatScore >= 70 ? 'var(--severity-critical)' : ($threatScore >= 40 ? 'var(--severity-high)' : ($threatScore >= 15 ? 'var(--severity-medium)' : 'var(--severity-low)'));

// Recent alerts (last 7)
$recentAlerts = $pdo->query(
    "SELECT a.*, ag.hostname FROM alerts a
     LEFT JOIN agents ag ON a.agent_id = ag.id
     ORDER BY a.created_at DESC LIMIT 7"
)->fetchAll();

// Agent statuses
$agents = $pdo->query(
    "SELECT id, hostname, ip_address, status, last_heartbeat, os_name FROM agents ORDER BY status DESC, hostname"
)->fetchAll();

// Hourly event chart data (last 24 hours)
$chartData = $pdo->query(
    "SELECT HOUR(created_at) as hour, module, COUNT(*) as count
     FROM events WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
     GROUP BY HOUR(created_at), module ORDER BY hour"
)->fetchAll();

$fileHours = array_fill(0, 24, 0);
$netHours  = array_fill(0, 24, 0);
$procHours = array_fill(0, 24, 0);
$regHours  = array_fill(0, 24, 0);
$memHours  = array_fill(0, 24, 0);
$assetHours = array_fill(0, 24, 0);
foreach ($chartData as $row) {
    $h = (int)$row['hour'];
    if ($row['module'] === 'file')    $fileHours[$h] = (int)$row['count'];
    if ($row['module'] === 'network') $netHours[$h]  = (int)$row['count'];
    if ($row['module'] === 'process') $procHours[$h] = (int)$row['count'];
    if ($row['module'] === 'registry') $regHours[$h] = (int)$row['count'];
    if ($row['module'] === 'memory')  $memHours[$h]  = (int)$row['count'];
    if ($row['module'] === 'asset')   $assetHours[$h] = (int)$row['count'];
}

// Recent activity timeline (last 10 events)
$recentActivity = $pdo->query(
    "SELECT e.module, e.severity, e.description, e.created_at, ag.hostname
     FROM events e LEFT JOIN agents ag ON e.agent_id = ag.id
     ORDER BY e.created_at DESC LIMIT 10"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HIPS — Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>(function(){var t=localStorage.getItem('hips-theme')||'dark';document.documentElement.setAttribute('data-theme',t);})();</script>
    <style>
        /* Dashboard-specific premium enhancements */
        .threat-gauge { 
            text-align:center; 
            padding:24px 0;
            background: linear-gradient(145deg, rgba(15, 23, 42, 0.5), rgba(8, 12, 28, 0.8));
            border-radius: var(--radius-lg);
            border: 1px solid rgba(56, 189, 248, 0.08);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.02), var(--shadow-sm);
        }
        .threat-ring {
            position:relative; width:160px; height:160px; margin:0 auto 16px;
            border-radius:50%;
            background: conic-gradient(
                var(--threat-color, var(--accent-cyan)) 0deg,
                var(--threat-color, var(--accent-cyan)) calc(var(--threat-pct, 0) * 3.6deg),
                rgba(100,116,139,0.08) 0deg
            );
            display:flex; align-items:center; justify-content:center;
            box-shadow: 0 0 30px rgba(0,0,0,0.3), 0 0 60px rgba(6,182,212,0.05), inset 0 0 15px rgba(0,0,0,0.15);
            animation: gaugeReveal 1.2s cubic-bezier(0.34, 1.56, 0.64, 1) both;
        }
        .threat-ring::before {
            content:''; position:absolute; inset:12px;
            border-radius:50%; 
            background: linear-gradient(145deg, rgba(15, 23, 42, 0.95), rgba(8, 12, 28, 0.98));
            z-index: 0;
            box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.4), inset 0 -1px 0 rgba(255,255,255,0.03);
        }
        .threat-ring .threat-inner {
            position:relative; z-index:1; text-align:center;
        }
        .threat-ring .threat-score {
            font-size:42px; font-weight:800; line-height:1;
            font-family:'JetBrains Mono',monospace;
            text-shadow: 0 0 20px rgba(6, 182, 212, 0.3);
        }
        .threat-ring .threat-label {
            font-size:11px; text-transform:uppercase; letter-spacing:2px;
            color:var(--text-muted); margin-top:6px;
            font-weight: 700;
        }
        @keyframes gaugeReveal { from { opacity:0; transform:scale(0.8) rotate(-180deg); } to { opacity:1; transform:scale(1) rotate(0); } }

        .timeline { position:relative; padding-left:24px; }
        .timeline::before {
            content:''; position:absolute; left:7px; top:0; bottom:0; width:2px;
            background: linear-gradient(to bottom, var(--accent-cyan), rgba(59,130,246,0.2), transparent);
            opacity: 0.4;
        }
        .timeline-item {
            position:relative; padding:12px 0 12px 16px; border:none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border-radius: var(--radius-sm);
        }
        .timeline-item:hover { 
            background: linear-gradient(90deg, rgba(6,182,212,0.04), transparent);
            transform:translateX(6px); 
        }
        .timeline-item::before {
            content:''; position:absolute; left:-21px; top:18px;
            width:10px; height:10px; border-radius:50%;
            background: linear-gradient(135deg, #06b6d4, #3b82f6); 
            border: 2px solid var(--bg-primary);
            box-shadow: 0 0 10px rgba(6, 182, 212, 0.5), 0 0 20px rgba(6, 182, 212, 0.2);
            z-index: 1;
        }
        .timeline-item .tl-time {
            font-size:10px; color:var(--text-muted);
            font-family:'JetBrains Mono',monospace;
            font-weight: 600;
        }
        .timeline-item .tl-desc {
            font-size:13px; color:var(--text-primary);
            margin-top:4px; line-height:1.5;
        }
        .timeline-item .tl-meta {
            font-size:11px; color:var(--text-muted); margin-top:4px;
            display: flex; align-items: center; gap: 6px;
        }

        .system-health { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        .health-item {
            display:flex; align-items:center; gap:12px;
            padding:12px 14px; border-radius:var(--radius-md);
            background: linear-gradient(135deg, rgba(15, 23, 42, 0.4), rgba(15, 23, 42, 0.2));
            border: 1px solid rgba(56, 189, 248, 0.06);
            transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .health-item:hover { 
            background: linear-gradient(135deg, rgba(6,182,212,0.06), rgba(15, 23, 42, 0.3));
            transform: translateY(-2px);
            border-color: rgba(6, 182, 212, 0.15);
            box-shadow: 0 4px 16px rgba(0,0,0,0.2), 0 0 20px rgba(6,182,212,0.03);
        }
        .health-indicator {
            width:10px; height:10px; border-radius:50%;
            position: relative; flex-shrink: 0;
        }
        .health-indicator::after {
            content: '';
            position: absolute;
            inset: -3px;
            border-radius: 50%;
            border: 1.5px solid currentColor;
            opacity: 0.3;
            animation: healthPulse 2s ease-in-out infinite;
        }
        .health-indicator.green { color:#22c55e; background:#22c55e; box-shadow:0 0 8px rgba(34,197,94,0.5); }
        .health-indicator.yellow { color:#eab308; background:#eab308; box-shadow:0 0 8px rgba(234,179,8,0.5); }
        .health-indicator.red { color:#ef4444; background:#ef4444; box-shadow:0 0 8px rgba(239,68,68,0.5); }
        
        @keyframes healthPulse { 
            0% { transform: scale(1); opacity: 0.4; }
            100% { transform: scale(1.8); opacity: 0; }
        }
        
        .health-label { font-size:12px; color:var(--text-secondary); flex:1; font-weight: 500; }
        .health-value { font-size:11px; font-weight:700; color:var(--text-primary);
            font-family:'JetBrains Mono',monospace; }

        .quick-actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        .action-card {
            flex: 1;
            padding: 16px;
            background: linear-gradient(145deg, rgba(15, 23, 42, 0.5), rgba(15, 23, 42, 0.3));
            border: 1px solid rgba(56, 189, 248, 0.08);
            border-radius: var(--radius-md);
            text-align: center;
            cursor: pointer;
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
        }
        .action-card:hover {
            background: linear-gradient(145deg, rgba(6,182,212,0.08), rgba(15, 23, 42, 0.5));
            transform: translateY(-4px);
            border-color: rgba(6, 182, 212, 0.25);
            box-shadow: 0 8px 24px rgba(0,0,0,0.3), 0 0 20px rgba(6,182,212,0.06);
        }
        .action-icon { font-size: 24px; margin-bottom: 8px; }
        .action-label { font-size: 12px; font-weight: 600; color: var(--text-primary); }
    </style>
</head>
<body>

<!-- ── Dragon Preloader (First Visit Only) ──────────────────── -->
<div class="dragon-preloader" id="dragonPreloader">
    <div class="dragon-bg"></div>
    <div class="dragon-stage">
        <!-- HIPS Text drawn by dragon fire -->
        <svg class="dragon-text-svg" viewBox="0 0 480 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- H -->
            <path d="M30 100V20M30 60H70M70 100V20" class="dragon-letter" stroke="url(#fireGrad)" stroke-width="5" stroke-linecap="round"/>
            <!-- I -->
            <path d="M110 20H150M130 20V100M110 100H150" class="dragon-letter dl2" stroke="url(#fireGrad)" stroke-width="5" stroke-linecap="round"/>
            <!-- P -->
            <path d="M190 100V20H230Q260 20 260 45Q260 70 230 70H190" class="dragon-letter dl3" stroke="url(#fireGrad)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
            <!-- S -->
            <path d="M350 35Q350 20 320 20H300Q280 20 280 37Q280 55 300 58H330Q355 62 355 80Q355 100 330 100H300Q278 100 278 85" class="dragon-letter dl4" stroke="url(#fireGrad)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
            <defs>
                <linearGradient id="fireGrad" x1="0" y1="0" x2="480" y2="120">
                    <stop offset="0%" stop-color="#06b6d4"/>
                    <stop offset="40%" stop-color="#22d3ee"/>
                    <stop offset="70%" stop-color="#f97316"/>
                    <stop offset="100%" stop-color="#ef4444"/>
                </linearGradient>
            </defs>
        </svg>

        <!-- Dragon SVG -->
        <svg class="dragon-svg" viewBox="0 0 200 180" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Dragon body -->
            <path d="M160 140C155 120 140 100 120 90C110 85 95 82 85 85C75 88 70 95 72 105C74 112 82 118 90 118C95 118 98 115 98 110C98 106 94 103 90 104" 
                  stroke="#06b6d4" stroke-width="2" fill="none" class="dragon-body"/>
            <!-- Wing -->
            <path d="M120 90C130 70 150 55 170 50C175 48 172 55 165 60C158 65 145 75 135 85" 
                  stroke="#3b82f6" stroke-width="2" fill="rgba(6,182,212,0.1)" class="dragon-wing"/>
            <!-- Head -->
            <path d="M160 140C165 138 172 135 175 130C178 125 176 120 170 118C168 117 164 118 162 120" 
                  stroke="#06b6d4" stroke-width="2.5" fill="none" class="dragon-head"/>
            <!-- Fire breath -->
            <path d="M175 130C185 128 195 120 200 110C195 115 188 118 182 122C190 112 196 100 198 88C192 100 185 110 178 116" 
                  stroke="url(#fireGrad)" stroke-width="1.5" fill="none" class="dragon-fire" opacity="0.8"/>
            <!-- Eye -->
            <circle cx="170" cy="125" r="2" fill="#22d3ee" class="dragon-eye"/>
            <!-- Tail -->
            <path d="M72 105C60 110 45 120 35 135C30 142 28 148 32 150C36 152 42 148 48 140" 
                  stroke="#06b6d4" stroke-width="1.5" fill="none" class="dragon-tail"/>
        </svg>

        <div class="dragon-subtitle">Security Dashboard</div>
    </div>
</div>
<script>
// Instant hide if not first load (prevents flash before bottom script runs)
if (localStorage.getItem('hips-dragon-shown-v2')) {
    document.getElementById('dragonPreloader').style.display = 'none';
}
</script>

<div class="app-layout">
    <?php include 'includes/sidebar.php'; ?>

    <main class="main-content">
        <!-- Page Header -->
        <div class="page-header animate-fadeIn">
            <div>
                <h1>Dashboard</h1>
                <span class="breadcrumb">HIPS / Overview</span>
            </div>
            <div class="header-actions" style="display:flex;gap:12px;align-items:center;">
                <div class="refresh-bar active" id="refreshBar">
                    <label class="toggle-switch" style="margin:0;">
                        <input type="checkbox" id="refreshToggle" checked>
                        <span class="toggle-slider"></span>
                    </label>
                    <span>Auto-refresh</span>
                    <span class="refresh-countdown" id="countdown">20</span>
                    <div class="refresh-progress">
                        <div class="refresh-progress-fill" id="progressFill" style="width:100%;"></div>
                    </div>
                </div>
                <span style="font-size:12px; color:var(--text-muted);">
                    <?= date('H:i:s') ?>
                </span>
                <button class="btn btn-secondary btn-sm" onclick="location.reload()">↻ Refresh</button>
            </div>
        </div>

        <!-- Stat Cards -->
        <div class="stat-grid">
            <div class="stat-card cyan animate-fadeIn delay-1">
                <div class="stat-icon">🖥</div>
                <div class="stat-value" data-count="<?= $totalAgents ?>"><?= $totalAgents ?></div>
                <div class="stat-label">Total Agents</div>
                <span class="stat-trend down">↑ <?= $onlineAgents ?> online</span>
            </div>
            <div class="stat-card red animate-fadeIn delay-2">
                <div class="stat-icon">🔔</div>
                <div class="stat-value" data-count="<?= $activeAlerts ?>"><?= $activeAlerts ?></div>
                <div class="stat-label">Active Alerts</div>
                <?php if ($activeAlerts > 0): ?>
                <span class="stat-trend up">⚠ Action needed</span>
                <?php else: ?>
                <span class="stat-trend down">✓ All clear</span>
                <?php endif; ?>
            </div>
            <div class="stat-card blue animate-fadeIn delay-3">
                <div class="stat-icon">📁</div>
                <div class="stat-value" data-count="<?= $fileEvents ?>"><?= $fileEvents ?></div>
                <div class="stat-label">File Events Today</div>
            </div>
            <div class="stat-card amber animate-fadeIn delay-4">
                <div class="stat-icon">🌐</div>
                <div class="stat-value" data-count="<?= $networkEvents ?>"><?= $networkEvents ?></div>
                <div class="stat-label">Network Events Today</div>
            </div>
            <div class="stat-card green animate-fadeIn delay-5">
                <div class="stat-icon">🔄</div>
                <div class="stat-value" data-count="<?= $processEvents ?>"><?= $processEvents ?></div>
                <div class="stat-label">Process Events</div>
            </div>
            <div class="stat-card purple animate-fadeIn delay-6">
                <div class="stat-icon">📝</div>
                <div class="stat-value" data-count="<?= $registryEvents ?>"><?= $registryEvents ?></div>
                <div class="stat-label">Registry Events</div>
            </div>
        </div>

        <!-- Security Status Overview -->
        <div class="card animate-fadeIn" style="margin-bottom:24px; background: linear-gradient(90deg, var(--bg-card), rgba(6, 182, 212, 0.05)); border-left: 4px solid <?= $threatScore > 50 ? 'var(--severity-high)' : 'var(--accent-cyan)' ?>;">
            <div style="display:flex; align-items:center; justify-content:space-between; padding:4px 10px;">
                <div style="display:flex; align-items:center; gap:16px;">
                    <div style="font-size:32px;">🛡️</div>
                    <div>
                        <h3 style="margin:0; color:var(--text-heading);">System Security Status: <?= $threatScore > 50 ? 'Attention Required' : 'Protected' ?></h3>
                        <p style="margin:4px 0 0; color:var(--text-muted); font-size:13px;">
                            <?php if ($threatScore > 50): ?>
                                High threat level detected. Please review the critical alerts immediately.
                            <?php else: ?>
                                No critical threats detected. All monitoring modules are active and reporting.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:11px; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px;">Last Scan</div>
                    <div style="font-size:14px; color:var(--text-primary); font-weight:600; font-family:'JetBrains Mono',monospace;"><?= date('M d, H:i') ?></div>
                </div>
            </div>
        </div>

        <!-- Row 2: Threat Gauge + System Health + Agent Status -->
        <div style="display:grid; grid-template-columns: 1fr 1.5fr 1fr; gap:20px; margin-bottom:24px;">
            <!-- Threat Level Gauge -->
            <div class="card scroll-reveal">
                <div class="card-title"><span class="icon">🎯</span> Threat Level</div>
                <div class="threat-gauge">
                    <div class="threat-ring" style="--threat-pct:<?= $threatScore ?>; --threat-color:<?= $threatColor ?>;">
                        <div class="threat-inner">
                            <div class="threat-score" style="color:<?= $threatColor ?>;"><?= $threatScore ?></div>
                            <div class="threat-label"><?= $threatLevel ?></div>
                        </div>
                    </div>
                    <div style="font-size:11px; color:var(--text-muted); margin-top:8px;">
                        🔴 <?= $criticalCount ?> Critical &nbsp; 🟠 <?= $highCount ?> High &nbsp; 🟡 <?= $medCount ?> Medium
                    </div>
                </div>
            </div>

            <!-- System Health -->
            <div class="card scroll-reveal">
                <div class="card-title"><span class="icon">💊</span> System Health</div>
                <div class="system-health">
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Apache Server</span>
                        <span class="health-value">Running</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">MySQL Database</span>
                        <span class="health-value">Connected</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator <?= $onlineAgents > 0 ? 'green' : 'red' ?>"></div>
                        <span class="health-label">Agent Connectivity</span>
                        <span class="health-value"><?= $onlineAgents ?>/<?= $totalAgents ?> Online</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator <?= $criticalCount > 0 ? 'red' : ($highCount > 0 ? 'yellow' : 'green') ?>"></div>
                        <span class="health-label">Security Posture</span>
                        <span class="health-value"><?= $threatLevel ?></span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">File Monitoring</span>
                        <span class="health-value"><?= $fileEvents ?> events</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Network Monitoring</span>
                        <span class="health-value"><?= $networkEvents ?> events</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Process Monitoring</span>
                        <span class="health-value"><?= $processEvents ?> events</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Registry Integrity</span>
                        <span class="health-value"><?= $registryEvents ?> events</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Memory Analysis</span>
                        <span class="health-value"><?= $memoryEvents ?> events</span>
                    </div>
                    <div class="health-item">
                        <div class="health-indicator green"></div>
                        <span class="health-label">Hardware Audit</span>
                        <span class="health-value"><?= $assetEvents ?> events</span>
                    </div>
                </div>
            </div>

            <!-- Agent Status -->
            <div class="card scroll-reveal reveal-right">
                <div class="card-title"><span class="icon">🖥</span> Agent Status</div>
                <?php foreach ($agents as $ag): ?>
                <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-color);">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span class="status-dot <?= $ag['status'] ?>"></span>
                        <div>
                            <span style="font-size:13px;font-weight:500;"><?= htmlspecialchars($ag['hostname']) ?></span>
                            <div style="font-size:10px;color:var(--text-muted);"><?= $ag['ip_address'] ?></div>
                        </div>
                    </div>
                    <span class="badge <?= $ag['status'] ?>"><?= ucfirst($ag['status']) ?></span>
                </div>
                <?php endforeach; ?>
                <?php if (empty($agents)): ?>
                <p style="color:var(--text-muted);font-size:13px;text-align:center;padding:20px;">No agents registered yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Row 3: Recent Alerts + Activity Timeline -->
        <div class="grid-2-1" style="margin-bottom:24px;">
            <!-- Recent Alerts Table -->
            <div class="card scroll-reveal">
                <div class="card-title" style="justify-content:space-between;">
                    <span><span class="icon">🔔</span> Recent Alerts</span>
                    <a href="alerts.php" class="btn btn-secondary btn-sm" style="font-size:10px;">View All →</a>
                </div>
                <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead>
                        <tr><th>Severity</th><th>Title</th><th>Agent</th><th>Module</th><th>Time</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentAlerts)): ?>
                        <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">No alerts yet. System is clean. ✓</td></tr>
                        <?php else: foreach ($recentAlerts as $alert): ?>
                        <tr>
                            <td><span class="badge <?= strtolower($alert['severity']) ?>"><?= $alert['severity'] ?></span></td>
                            <td><?= htmlspecialchars($alert['title']) ?></td>
                            <td style="font-family:'JetBrains Mono',monospace;font-size:12px;"><?= htmlspecialchars($alert['hostname'] ?? 'N/A') ?></td>
                            <td><?= ucfirst($alert['module']) ?></td>
                            <td style="color:var(--text-muted);font-size:12px;"><?= date('H:i:s', strtotime($alert['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
                </div>
            </div>

            <!-- Activity Timeline + Quick Command -->
            <div style="display:flex;flex-direction:column;gap:20px;">
                <div class="card scroll-reveal reveal-right">
                    <div class="card-title"><span class="icon">📜</span> Activity Timeline</div>
                <div class="timeline" style="max-height:300px;overflow-y:auto;">
                    <?php if (empty($recentActivity)): ?>
                    <p style="color:var(--text-muted);font-size:12px;text-align:center;padding:20px;">No activity yet.</p>
                    <?php else: foreach ($recentActivity as $act): ?>
                    <div class="timeline-item">
                        <div class="tl-time"><?= date('H:i:s', strtotime($act['created_at'])) ?></div>
                        <div class="tl-desc"><?= htmlspecialchars(substr($act['description'] ?? 'Event recorded', 0, 80)) ?></div>
                        <div class="tl-meta">
                            <span>📍 <?= htmlspecialchars($act['hostname'] ?? 'System') ?></span>
                            <span>•</span>
                            <span class="badge <?= strtolower($act['severity'] ?? 'low') ?>" style="font-size:8px; padding:1px 4px;"><?= $act['severity'] ?></span>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>

            <!-- Quick Actions Card -->
            <div class="card scroll-reveal reveal-right">
                <div class="card-title"><span class="icon">⚡</span> Quick Actions</div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                    <a href="commands.php?action=scan" class="action-card">
                        <div class="action-icon">🔍</div>
                        <div class="action-label">Deep Scan</div>
                    </a>
                    <a href="reports.php" class="action-card">
                        <div class="action-icon">📊</div>
                        <div class="action-label">Report</div>
                    </a>
                    <a href="agents.php" class="action-card">
                        <div class="action-icon">🖥️</div>
                        <div class="action-label">Manage</div>
                    </a>
                    <a href="settings.php" class="action-card">
                        <div class="action-icon">⚙️</div>
                        <div class="action-label">Settings</div>
                    </a>
                </div>
                <div style="margin-top:16px; padding:12px; background:var(--bg-secondary); border-radius:var(--radius-md); border:1px dashed var(--border-color);">
                    <div style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">System Integrity</div>
                    <div style="height:6px; background:rgba(255,255,255,0.05); border-radius:3px; overflow:hidden;">
                        <div style="width:94%; height:100%; background:var(--accent-cyan); box-shadow:0 0 8px var(--accent-cyan);"></div>
                    </div>
                    <div style="display:flex; justify-content:space-between; margin-top:6px; font-size:10px; color:var(--text-muted);">
                        <span>94% Secure</span>
                        <span>v2.4.0</span>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <!-- 24-Hour Activity Chart -->
        <div class="card scroll-reveal reveal-scale">
            <div class="card-title"><span class="icon">📊</span> 24-Hour Event Activity</div>
            <div class="chart-container">
                <canvas id="activityChart"></canvas>
            </div>
        </div>
    </main>
</div>

<script>
// ── 24-Hour Activity Chart ───────────────────────────────────
const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
const gridColor = isDark ? 'rgba(56,189,248,0.05)' : 'rgba(15,23,42,0.06)';
const labelColor = isDark ? '#64748b' : '#64748b';
const legendColor = isDark ? '#94a3b8' : '#475569';

const ctx = document.getElementById('activityChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_map(fn($h) => str_pad($h, 2, '0', STR_PAD_LEFT) . ':00', range(0, 23))) ?>,
        datasets: [
            {
                label: 'File Events',
                data: <?= json_encode(array_values($fileHours)) ?>,
                backgroundColor: isDark ? 'rgba(59, 130, 246, 0.6)' : 'rgba(37, 99, 235, 0.65)',
                borderColor: isDark ? 'rgba(59, 130, 246, 1)' : 'rgba(37, 99, 235, 1)',
                borderWidth: 1,
                borderRadius: 4,
            },
            {
                label: 'Network Events',
                data: <?= json_encode(array_values($netHours)) ?>,
                backgroundColor: isDark ? 'rgba(6, 182, 212, 0.6)' : 'rgba(8, 145, 178, 0.6)',
                borderColor: isDark ? 'rgba(6, 182, 212, 1)' : 'rgba(8, 145, 178, 1)',
                borderWidth: 1,
                borderRadius: 4,
            },
            {
                label: 'Process Events',
                data: <?= json_encode(array_values($procHours)) ?>,
                backgroundColor: 'rgba(34, 197, 94, 0.6)',
                borderColor: 'rgba(34, 197, 94, 1)',
                borderWidth: 1,
                borderRadius: 4,
            },
            {
                label: 'Registry Events',
                data: <?= json_encode(array_values($regHours)) ?>,
                backgroundColor: 'rgba(168, 85, 247, 0.6)',
                borderColor: 'rgba(168, 85, 247, 1)',
                borderWidth: 1,
                borderRadius: 4,
            },
            {
                label: 'Memory Events',
                data: <?= json_encode(array_values($memHours)) ?>,
                backgroundColor: 'rgba(239, 68, 68, 0.6)',
                borderColor: 'rgba(239, 68, 68, 1)',
                borderWidth: 1,
                borderRadius: 4,
            },
            {
                label: 'Asset Events',
                data: <?= json_encode(array_values($assetHours)) ?>,
                backgroundColor: 'rgba(234, 179, 8, 0.6)',
                borderColor: 'rgba(234, 179, 8, 1)',
                borderWidth: 1,
                borderRadius: 4,
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { labels: { color: legendColor, font: { family: 'Inter', size: 12 } } }
        },
        scales: {
            x: { ticks: { color: labelColor, font: { size: 10 } }, grid: { color: gridColor } },
            y: { beginAtZero: true, ticks: { color: labelColor }, grid: { color: gridColor } }
        }
    }
});

// ── Auto-Refresh with Toggle ─────────────────────────────────
(function() {
    const INTERVAL = 20;
    let remaining = INTERVAL;
    let timer = null;

    const toggle      = document.getElementById('refreshToggle');
    const countdownEl  = document.getElementById('countdown');
    const progressFill = document.getElementById('progressFill');
    const refreshBar   = document.getElementById('refreshBar');

    function tick() {
        remaining--;
        countdownEl.textContent = remaining;
        progressFill.style.width = ((remaining / INTERVAL) * 100) + '%';
        if (remaining <= 0) location.reload();
    }

    function start() {
        remaining = INTERVAL;
        countdownEl.textContent = remaining;
        progressFill.style.width = '100%';
        timer = setInterval(tick, 1000);
    }

    function stop() {
        clearInterval(timer);
        timer = null;
        countdownEl.textContent = '—';
        progressFill.style.width = '0%';
    }

    toggle.addEventListener('change', function() {
        if (this.checked) { refreshBar.classList.add('active'); start(); }
        else { refreshBar.classList.remove('active'); stop(); }
    });

    start();
})();
</script>

<!-- ── Dragon Preloader Orchestration (runs after ALL DOM loaded) ── -->
<script>
(function() {
    var dragon = document.getElementById('dragonPreloader');
    var normalPreloader = document.getElementById('pagePreloader');
    var isFirstLoad = !localStorage.getItem('hips-dragon-shown-v2');

    if (!dragon) return;

    if (isFirstLoad) {
        // FIRST VISIT: Show dragon, hide normal preloader
        dragon.style.display = 'flex';
        if (normalPreloader) {
            normalPreloader.style.display = 'none';
        }

        // Mark as shown so it never plays again
        localStorage.setItem('hips-dragon-shown-v2', '1');

        // After dragon animation (~4.2s), exit with transition
        setTimeout(function() {
            dragon.classList.add('dragon-exit');
            // After exit transition (0.8s), fully remove
            setTimeout(function() {
                dragon.style.display = 'none';
                // Also ensure normal preloader is gone
                if (normalPreloader) {
                    normalPreloader.classList.add('hidden');
                    normalPreloader.style.display = 'none';
                }
            }, 900);
        }, 4200);
    } else {
        // NOT FIRST VISIT: Remove dragon immediately, let normal preloader run
        dragon.style.display = 'none';
        dragon.parentNode.removeChild(dragon);
    }
})();
</script>
</body>
</html>
