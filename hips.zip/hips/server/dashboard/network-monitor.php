<?php
$currentPage = 'network-monitor';
require_once 'includes/session.php';

// ── Handle IP Whitelist Actions ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'whitelist_add') {
        $ip    = trim($_POST['ip'] ?? '');
        $label = trim($_POST['label'] ?? '');
        if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP)) {
            try {
                // 1. Add to local database
                $stmt = $pdo->prepare(
                    "INSERT INTO ip_whitelist (ip_address, label, added_by) VALUES (:ip, :label, :user)"
                );
                $stmt->execute([':ip' => $ip, ':label' => $label, ':user' => $adminUsername]);

                // 2. Dispatch command to all active agents
                $activeAgents = $pdo->query("SELECT id FROM agents WHERE status = 'online'")->fetchAll();
                $paramsJson = json_encode(['ip' => $ip]);
                foreach ($activeAgents as $agent) {
                    $cmdStmt = $pdo->prepare(
                        "INSERT INTO commands (agent_id, command_type, parameters_json, priority, admin_note, issued_by)
                         VALUES (:agent_id, 'WHITELIST_ADD', :params, 'high', 'Manual Whitelist Addition', :user)"
                    );
                    $cmdStmt->execute([
                        ':agent_id' => $agent['id'],
                        ':params'   => $paramsJson,
                        ':user'     => $adminUsername
                    ]);
                }
            } catch (PDOException $e) {
                if ($e->getCode() != 23000) { 
                    $_SESSION['hips_error'] = "Failed to whitelist IP: " . $e->getMessage();
                } else {
                    $_SESSION['hips_info'] = "IP $ip is already whitelisted.";
                }
            }
        }
        header('Location: network-monitor.php'); exit;
    }

    if ($action === 'whitelist_delete') {
        $wlId = (int)($_POST['whitelist_id'] ?? 0);
        if ($wlId > 0) {
            // Get IP before deleting
            $stmt = $pdo->prepare("SELECT ip_address FROM ip_whitelist WHERE id = :id");
            $stmt->execute([':id' => $wlId]);
            $ip = $stmt->fetchColumn();

            if ($ip) {
                // 1. Delete from local database
                $pdo->prepare("DELETE FROM ip_whitelist WHERE id = :id")->execute([':id' => $wlId]);

                // 2. Dispatch removal command to all active agents
                $activeAgents = $pdo->query("SELECT id FROM agents WHERE status = 'online'")->fetchAll();
                $paramsJson = json_encode(['ip' => $ip]);
                foreach ($activeAgents as $agent) {
                    $cmdStmt = $pdo->prepare(
                        "INSERT INTO commands (agent_id, command_type, parameters_json, priority, admin_note, issued_by)
                         VALUES (:agent_id, 'WHITELIST_REMOVE', :params, 'high', 'Manual Whitelist Removal', :user)"
                    );
                    $cmdStmt->execute([
                        ':agent_id' => $agent['id'],
                        ':params'   => $paramsJson,
                        ':user'     => $adminUsername
                    ]);
                }
            }
        }
        header('Location: network-monitor.php'); exit;
    }
}

// ── Fetch Data ───────────────────────────────────────────────
$networkEvents = $pdo->query(
    "SELECT e.*, ag.hostname FROM events e
     LEFT JOIN agents ag ON e.agent_id = ag.id
     WHERE e.module = 'network'
     ORDER BY e.created_at DESC LIMIT 20"
)->fetchAll();

$totalNetEvents = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module='network'")->fetchColumn();
$todayNetEvents = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE module='network' AND DATE(created_at) = CURDATE()")->fetchColumn();

// Fetch whitelisted IPs
$whitelistIPs = [];
try {
    $whitelistIPs = $pdo->query("SELECT * FROM ip_whitelist ORDER BY created_at DESC")->fetchAll();
} catch (PDOException $e) {
    // Table may not exist yet
}
$whitelistCount = count($whitelistIPs);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HIPS — Network Monitor</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('hips-theme')||'dark';document.documentElement.setAttribute('data-theme',t);})();</script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        .whitelist-card { margin-top: 0; }
        .whitelist-form {
            display: flex; gap: 8px; margin-top: 12px;
            align-items: flex-end;
        }
        .whitelist-form .form-group { margin-bottom: 0; flex: 1; }
        .whitelist-form .form-group:first-child { flex: 1.2; }
        .whitelist-item {
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 14px; border-bottom: 1px solid var(--border-color);
            transition: all 0.2s ease;
        }
        .whitelist-item:last-child { border-bottom: none; }
        .whitelist-item:hover { background: var(--bg-table-hover); }
        .whitelist-ip {
            font-family: 'JetBrains Mono', monospace; font-size: 13px;
            color: var(--accent-cyan); font-weight: 600;
        }
        .whitelist-label {
            font-size: 11px; color: var(--text-muted); margin-left: 12px;
        }
        .whitelist-meta {
            font-size: 10px; color: var(--text-muted);
            display: flex; align-items: center; gap: 8px;
        }
    </style>
</head>
<body>
<div class="app-layout">
    <?php include 'includes/sidebar.php'; ?>
    <main class="main-content">
        <div class="page-header animate-fadeIn">
            <div><h1>Network Monitor</h1><span class="breadcrumb">HIPS / Monitoring / Network</span></div>
        </div>

        <?php if (isset($_SESSION['hips_error'])): ?>
            <div class="alert critical animate-fadeIn" style="margin-bottom:20px; border-radius:8px; padding:12px 16px; display:flex; align-items:center; gap:12px; background:rgba(239,68,68,0.1); border:1px solid var(--severity-critical); color:var(--severity-critical);">
                <i class="fa-solid fa-circle-exclamation"></i>
                <div style="flex:1; font-size:13px;"><?= $_SESSION['hips_error'] ?></div>
                <button onclick="this.parentElement.remove()" style="background:none; border:none; color:inherit; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <?php unset($_SESSION['hips_error']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['hips_info'])): ?>
            <div class="alert low animate-fadeIn" style="margin-bottom:20px; border-radius:8px; padding:12px 16px; display:flex; align-items:center; gap:12px; background:rgba(34,197,94,0.1); border:1px solid var(--severity-low); color:var(--severity-low);">
                <i class="fa-solid fa-circle-info"></i>
                <div style="flex:1; font-size:13px;"><?= $_SESSION['hips_info'] ?></div>
                <button onclick="this.parentElement.remove()" style="background:none; border:none; color:inherit; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <?php unset($_SESSION['hips_info']); ?>
        <?php endif; ?>

        <div class="status-strip animate-fadeIn delay-1">
            <div class="strip-item"><span class="status-dot online"></span><span class="value">Monitor Active</span></div>
            <div class="divider"></div>
            <div class="strip-item"><span class="label">Total Events</span><span class="value"><?= $totalNetEvents ?></span></div>
            <div class="divider"></div>
            <div class="strip-item"><span class="label">Today</span><span class="value"><?= $todayNetEvents ?></span></div>
            <div class="divider"></div>
            <div class="strip-item"><span class="label">Whitelisted IPs</span><span class="value"><?= $whitelistCount ?></span></div>
            <div class="divider"></div>
            <div class="strip-item"><span class="label">Interface</span><span class="value">Ethernet (Primary)</span></div>
        </div>

        <div class="grid-2" style="margin-bottom:20px;">
            <!-- Active Connections -->
            <div class="card animate-fadeIn delay-2">
                <div class="card-title"><span class="icon">🔗</span> Active Connections (Sample)</div>
                <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead><tr><th>Local</th><th>Remote</th><th>Protocol</th><th>Status</th><th>Threat</th></tr></thead>
                    <tbody>
                        <tr><td style="font-size:12px;">0.0.0.0:80</td><td style="font-size:12px;">0.0.0.0:0</td><td>TCP</td><td style="color:var(--severity-low);">LISTENING</td><td><span class="badge low">Low</span></td></tr>
                        <tr><td style="font-size:12px;">0.0.0.0:443</td><td style="font-size:12px;">0.0.0.0:0</td><td>TCP</td><td style="color:var(--severity-low);">LISTENING</td><td><span class="badge low">Low</span></td></tr>
                        <tr><td style="font-size:12px;">0.0.0.0:3306</td><td style="font-size:12px;">0.0.0.0:0</td><td>TCP</td><td style="color:var(--severity-medium);">LISTENING</td><td><span class="badge high">High</span></td></tr>
                    </tbody>
                </table>
                </div>
            </div>

            <!-- Open Ports -->
            <div class="card animate-fadeIn delay-2">
                <div class="card-title"><span class="icon">🚪</span> Open Ports</div>
                <table class="data-table">
                    <thead><tr><th>Port</th><th>Service</th><th>Risk</th></tr></thead>
                    <tbody>
                        <tr><td>80</td><td>HTTP (Apache)</td><td><span class="badge low">Low</span></td></tr>
                        <tr><td>443</td><td>HTTPS</td><td><span class="badge low">Low</span></td></tr>
                        <tr><td>3306</td><td>MySQL</td><td><span class="badge high">High</span></td></tr>
                        <tr><td>3389</td><td>RDP</td><td><span class="badge critical">Critical</span></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="grid-2" style="margin-bottom:20px;">
            <!-- IP Whitelist Management -->
            <div class="card animate-fadeIn delay-3 whitelist-card">
                <div class="card-title" style="justify-content:space-between;">
                    <span><span class="icon">✅</span> IP Whitelist</span>
                    <span style="font-size:11px;color:var(--text-muted);"><?= $whitelistCount ?> entries</span>
                </div>

                <?php if (empty($whitelistIPs)): ?>
                <div style="text-align:center; padding:24px; color:var(--text-muted); font-size:13px;">
                    <div style="font-size:32px; margin-bottom:8px;">🔓</div>
                    No whitelisted IPs yet. Add trusted IPs below.
                </div>
                <?php else: ?>
                <div style="max-height:240px; overflow-y:auto;">
                    <?php foreach ($whitelistIPs as $wl): ?>
                    <div class="whitelist-item">
                        <div>
                            <span class="whitelist-ip"><?= htmlspecialchars($wl['ip_address']) ?></span>
                            <?php if (!empty($wl['label'])): ?>
                            <span class="whitelist-label"><?= htmlspecialchars($wl['label']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex; align-items:center; gap:12px;">
                            <span class="whitelist-meta">
                                <span>👤 <?= htmlspecialchars($wl['added_by'] ?? 'system') ?></span>
                                <span><?= date('M j', strtotime($wl['created_at'])) ?></span>
                            </span>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="whitelist_delete">
                                <input type="hidden" name="whitelist_id" value="<?= $wl['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm" title="Remove from whitelist" onclick="return confirm('Remove this IP from the whitelist?')">🗑</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Add to Whitelist Form -->
                <form method="POST" class="whitelist-form">
                    <input type="hidden" name="action" value="whitelist_add">
                    <div class="form-group">
                        <label>IP Address</label>
                        <input type="text" name="ip" class="form-control" placeholder="e.g. 192.168.1.100" required>
                    </div>
                    <div class="form-group">
                        <label>Label (optional)</label>
                        <input type="text" name="label" class="form-control" placeholder="e.g. Office Gateway">
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="height:38px;">+ Whitelist</button>
                </form>
            </div>

            <!-- IP Blacklist -->
            <div class="card animate-fadeIn delay-3">
                <div class="card-title"><span class="icon">🚫</span> IP Blacklist</div>
                <table class="data-table">
                    <thead><tr><th>IP Address</th><th>Reason</th><th>Added</th><th>Action</th></tr></thead>
                    <tbody>
                        <tr><td style="font-family:'JetBrains Mono',monospace;">198.51.100.1</td><td>Known malicious</td><td>Apr 14</td><td><button class="btn btn-danger btn-sm">Remove</button></td></tr>
                        <tr><td style="font-family:'JetBrains Mono',monospace;">203.0.113.50</td><td>C2 server</td><td>Apr 14</td><td><button class="btn btn-danger btn-sm">Remove</button></td></tr>
                    </tbody>
                </table>
                <div style="margin-top:12px;display:flex;gap:8px;">
                    <input type="text" class="form-control" placeholder="Enter IP to block..." style="flex:1;">
                    <button class="btn btn-primary btn-sm">+ Block</button>
                </div>
            </div>
        </div>

        <!-- Traffic Chart -->
        <div class="card animate-fadeIn delay-4" style="margin-bottom:20px;">
            <div class="card-title"><span class="icon">📊</span> Inbound vs Outbound Traffic</div>
            <div class="chart-container">
                <canvas id="trafficChart"></canvas>
            </div>
        </div>

        <!-- Recent Network Events -->
        <div class="card animate-fadeIn delay-4">
            <div class="card-title"><span class="icon">🌐</span> Recent Network Events</div>
            <div style="overflow-x:auto;">
            <table class="data-table">
                <thead><tr><th>Time</th><th>Agent</th><th>Event Type</th><th>Severity</th><th>Destination</th></tr></thead>
                <tbody>
                    <?php if (empty($networkEvents)): ?>
                    <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">No network events recorded yet.</td></tr>
                    <?php else: foreach ($networkEvents as $e): ?>
                    <tr>
                        <td style="font-size:12px;color:var(--text-muted);"><?= date('M j, H:i:s', strtotime($e['created_at'])) ?></td>
                        <td><?= htmlspecialchars($e['hostname'] ?? 'N/A') ?></td>
                        <td style="font-family:'JetBrains Mono',monospace;font-size:12px;"><?= htmlspecialchars($e['event_type']) ?></td>
                        <td><span class="badge <?= strtolower($e['severity']) ?>"><?= $e['severity'] ?></span></td>
                        <td style="font-family:'JetBrains Mono',monospace;font-size:12px;"><?= htmlspecialchars($e['destination'] ?? 'N/A') ?></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
            </div>
        </div>
    </main>
</div>

<script>
new Chart(document.getElementById('trafficChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: ['00:00','04:00','08:00','12:00','16:00','20:00'],
        datasets: [
            { label: 'Inbound', data: [12,8,25,38,42,15], backgroundColor: 'rgba(59,130,246,0.6)', borderRadius: 4 },
            { label: 'Outbound', data: [8,5,20,30,35,12], backgroundColor: 'rgba(6,182,212,0.6)', borderRadius: 4 }
        ]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#94a3b8' } } },
        scales: {
            x: { ticks: { color: '#64748b' }, grid: { color: 'rgba(56,189,248,0.05)' } },
            y: { beginAtZero: true, ticks: { color: '#64748b' }, grid: { color: 'rgba(56,189,248,0.05)' } }
        }
    }
});
</script>
</body>
</html>
