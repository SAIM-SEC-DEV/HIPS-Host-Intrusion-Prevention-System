-- ============================================================
-- HIPS Database Migration v1.2 — osquery Integration
-- ============================================================
-- Backward-compatible schema changes to support cross-platform
-- agents. All existing data and queries remain unaffected.
--
-- Changes:
--   1. Add `host_os` column to `agents` table (nullable, default NULL)
--   2. Add `host_os` to `events` table for cross-platform event filtering
--   3. Add index on host_os for dashboard filtering
--
-- Safety: All columns are nullable with defaults, so existing
-- agents that don't send `host_os` will continue to work.
-- ============================================================

-- ── Agents table: Add host OS field ─────────────────────────
ALTER TABLE `agents`
  ADD COLUMN IF NOT EXISTS `host_os` VARCHAR(20) DEFAULT NULL
  COMMENT 'Operating system: windows, linux, darwin'
  AFTER `hostname`;

-- ── Events table: Add host OS field ─────────────────────────
ALTER TABLE `events`
  ADD COLUMN IF NOT EXISTS `host_os` VARCHAR(20) DEFAULT NULL
  COMMENT 'Operating system of the reporting agent'
  AFTER `agent_id`;

-- ── Alerts table: Add host OS field ─────────────────────────
ALTER TABLE `alerts`
  ADD COLUMN IF NOT EXISTS `host_os` VARCHAR(20) DEFAULT NULL
  COMMENT 'Operating system of the reporting agent'
  AFTER `agent_id`;

-- ── Index for dashboard OS filtering ────────────────────────
-- Only create if not exists (safe for re-runs)
CREATE INDEX IF NOT EXISTS `idx_events_host_os` ON `events` (`host_os`);
CREATE INDEX IF NOT EXISTS `idx_alerts_host_os` ON `alerts` (`host_os`);
CREATE INDEX IF NOT EXISTS `idx_agents_host_os` ON `agents` (`host_os`);

-- ============================================================
-- VERIFICATION QUERY
-- ============================================================
-- Run this to verify the migration:
--   SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
--   FROM INFORMATION_SCHEMA.COLUMNS
--   WHERE TABLE_NAME IN ('agents', 'events', 'alerts')
--     AND COLUMN_NAME = 'host_os';
-- ============================================================
