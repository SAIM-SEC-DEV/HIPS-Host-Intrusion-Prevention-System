<?php
require_once __DIR__ . '/config/db_connect.php';

try {
    $pdo->exec("INSERT INTO settings (setting_key, setting_value, category, description) VALUES 
        ('monitored_folders', 'C:\\Windows\\System32,C:\\Users\\Desktop', 'security', 'Comma-separated list of folders monitored for access and changes'),
        ('process_whitelist', 'svchost.exe,explorer.exe,msedge.exe', 'security', 'Comma-separated list of trusted processes to ignore in file monitor')
        ON DUPLICATE KEY UPDATE setting_key=setting_key;");
    echo "Settings updated successfully.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
