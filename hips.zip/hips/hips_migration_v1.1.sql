-- ============================================================
-- HIPS Database Migration: Security & Performance Fixes
-- Run this script ONCE in phpMyAdmin or via MySQL CLI:
--   mysql -u root hips_db < hips_migration_v1.1.sql
-- ============================================================

-- ── FIX 1.4 & 3.2: login_attempts table ─────────────────────
-- Used for both admin brute-force protection and
-- agent registration rate-limiting.
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id`                 INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `ip_address`         VARCHAR(45)     NOT NULL,
    `username_attempted` VARCHAR(100)    NOT NULL DEFAULT '',
    `attempt_time`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ip_time` (`ip_address`, `attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── FIX 3.2: Add registration_key to settings ────────────────
-- This is the shared secret agents must include when registering.
-- IMPORTANT: Change this value in the HIPS settings page after running!
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `setting_label`, `setting_description`)
VALUES (
    'registration_key',
    SHA2(CONCAT('hips-', UUID(), '-secret'), 256),
    'Agent Registration Key',
    'Shared secret that new agents must provide when registering. Change this regularly.'
);

-- ── FIX 3.3: Optimize events & alerts tables with indexes ────
-- These indexes dramatically speed up the COUNT(*) queries on dashboard.
ALTER TABLE `events`
    ADD INDEX IF NOT EXISTS `idx_module_date`   (`module`, `created_at`),
    ADD INDEX IF NOT EXISTS `idx_severity_date` (`severity`, `created_at`),
    ADD INDEX IF NOT EXISTS `idx_agent_date`    (`agent_id`, `created_at`);

ALTER TABLE `alerts`
    ADD INDEX IF NOT EXISTS `idx_severity_status` (`severity`, `status`),
    ADD INDEX IF NOT EXISTS `idx_status_date`      (`status`, `created_at`);

-- ── FIX: Add status index to commands table ──────────────────
ALTER TABLE `commands`
    ADD INDEX IF NOT EXISTS `idx_agent_status`  (`agent_id`, `status`),
    ADD INDEX IF NOT EXISTS `idx_issued_at`     (`issued_at`);

-- ── View current registration key (run separately to share with agents) ──
-- SELECT setting_value FROM settings WHERE setting_key='registration_key';

SELECT 'HIPS Migration v1.1 completed successfully.' AS Status;
