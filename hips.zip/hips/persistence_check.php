<?php
require_once __DIR__ . '/config/db_connect.php';

$logFile = __DIR__ . '/persistence_log.txt';
$time = date('Y-m-d H:i:s');

try {
    $agentCount = $pdo->query("SELECT COUNT(*) FROM agents")->fetchColumn();
    $eventCount = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
    $wlCount    = $pdo->query("SELECT COUNT(*) FROM ip_whitelist")->fetchColumn();
    
    $entry = "[$time] DB State: Agents=$agentCount, Events=$eventCount, Whitelist=$wlCount\n";
    file_put_contents($logFile, $entry, FILE_APPEND);
    echo "Persistence log updated: $entry";
} catch (Exception $e) {
    echo "Log Error: " . $e->getMessage();
}
