<?php
$file = 'dashboard/assets/css/style.css';
echo "File: $file<br>";
echo "Exists: " . (file_exists($file) ? 'Yes' : 'No') . "<br>";
echo "Size: " . filesize($file) . " bytes<br>";
echo "Last Modified: " . date('Y-m-d H:i:s', filemtime($file)) . "<br>";
echo "Content Start: " . htmlspecialchars(substr(file_get_contents($file), 0, 100)) . "<br>";
?>
