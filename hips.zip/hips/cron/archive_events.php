<?php
/**
 * ============================================================
 * HIPS — Database Event Archival Script
 * ============================================================
 * 
 * FIX 5.4: Database Event Archival
 * Moves events older than 30 days into an events_archive table
 * to keep the primary `events` table fast and optimized.
 * 
 * Should be run via cron daily:
 * 0 2 * * * php /E/XAMPP/htdocs/hips/cron/archive_events.php
 */

require_once __DIR__ . '/../config/db_connect.php';

try {
    $pdo->beginTransaction();

    // 1. Ensure archive table exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS events_archive LIKE events;
    ");

    // 2. Copy old events to archive
    $stmt = $pdo->exec("
        INSERT INTO events_archive
        SELECT * FROM events
        WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");

    // 3. Delete old events from primary table
    $deleted = $pdo->exec("
        DELETE FROM events
        WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");

    $pdo->commit();
    echo "[HIPS Archive] Successfully archived $deleted old events.\n";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "[HIPS Archive] Error: " . $e->getMessage() . "\n";
}
