<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->prepare("SELECT uuid, auth_token FROM agents WHERE id = 1");
$stmt->execute();
$agent = $stmt->fetch();

echo $agent['uuid'] . "|" . $agent['auth_token'];
file_put_contents(__DIR__ . '/agent_info.txt', $agent['uuid'] . "|" . $agent['auth_token']);
