<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->prepare("SELECT id, hostname, uuid, auth_token FROM agents WHERE id = 1");
$stmt->execute();
$agent = $stmt->fetch();

echo "Agent 1 Info:\n";
print_r($agent);

// Insert a RESTART command for this agent
$stmt = $pdo->prepare("INSERT INTO commands (agent_id, command_type, parameters, status) VALUES (1, 'RESTART', '{}', 'pending')");
if ($stmt->execute()) {
    echo "\nRESTART command inserted successfully.";
} else {
    echo "\nFailed to insert RESTART command.";
}
