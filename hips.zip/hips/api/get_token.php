<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT hostname, auth_token FROM agents ORDER BY last_heartbeat DESC LIMIT 1");
$agent = $stmt->fetch();

echo "<h3>Agent Info</h3>";
echo "Hostname: " . $agent['hostname'] . "<br>";
echo "Token: " . $agent['auth_token'] . "<br>";

file_put_contents(__DIR__ . '/token_fix.txt', $agent['auth_token']);
