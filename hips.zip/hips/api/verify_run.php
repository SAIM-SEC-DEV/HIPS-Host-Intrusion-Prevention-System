<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT hostname, last_heartbeat, TIMESTAMPDIFF(SECOND, last_heartbeat, NOW()) as seconds_ago FROM agents ORDER BY last_heartbeat DESC LIMIT 1");
$agent = $stmt->fetch(PDO::FETCH_ASSOC);

$status = "OFFLINE";
if ($agent && $agent['seconds_ago'] < 60) {
    $status = "ONLINE";
}

$output = "Verification Result:\n";
$output .= "Status: " . $status . "\n";
$output .= "Agent Hostname: " . ($agent['hostname'] ?? 'N/A') . "\n";
$output .= "Last Heartbeat: " . ($agent['last_heartbeat'] ?? 'N/A') . "\n";
$output .= "Seconds Ago: " . ($agent['seconds_ago'] ?? 'N/A') . "\n";
$output .= "Checked At: " . date('Y-m-d H:i:s') . "\n";

file_put_contents(__DIR__ . '/verify_result.txt', $output);
echo "Result written to verify_result.txt";
