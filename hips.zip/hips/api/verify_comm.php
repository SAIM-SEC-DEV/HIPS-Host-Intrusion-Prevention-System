<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT hostname, last_heartbeat FROM agents WHERE id = 1");
$agent = $stmt->fetch();

$now = new DateTime();
$last = new DateTime($agent['last_heartbeat']);
$diff = $now->getTimestamp() - $last->getTimestamp();

echo "Agent Status Verification:\n";
echo "Hostname: " . $agent['hostname'] . "\n";
echo "Last Heartbeat: " . $agent['last_heartbeat'] . "\n";
echo "Current Server Time: " . $now->format('Y-m-d H:i:s') . "\n";
echo "Seconds since last heartbeat: $diff\n";

if ($diff < 60) {
    echo "STATUS: ONLINE\n";
} else {
    echo "STATUS: OFFLINE\n";
}

file_put_contents(__DIR__ . '/comm_status.txt', "Last Heartbeat: {$agent['last_heartbeat']} | Current: " . $now->format('Y-m-d H:i:s') . " | Diff: $diff s");
