<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT module, event_type, severity, title, created_at FROM events ORDER BY created_at DESC LIMIT 5");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

$output = "Recent Events in DB:\n";
foreach ($events as $e) {
    $output .= "[{$e['created_at']}] [{$e['severity']}] {$e['event_type']} - {$e['title']}\n";
}
$output .= "\nCurrent Server Time: " . date('Y-m-d H:i:s') . "\n";

file_put_contents(__DIR__ . '/event_verify.txt', $output);
echo "Verification complete.";
