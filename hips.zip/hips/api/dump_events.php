<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT module, event_type, severity, title, created_at FROM events ORDER BY created_at DESC LIMIT 5");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

file_put_contents(__DIR__ . '/events_dump.json', json_encode($events, JSON_PRETTY_PRINT));
echo "Events dumped to events_dump.json";
