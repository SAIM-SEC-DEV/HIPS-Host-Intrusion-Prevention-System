<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT COUNT(*) as count FROM events WHERE created_at > (NOW() - INTERVAL 10 MINUTE)");
$row = $stmt->fetch();

$stmt2 = $pdo->query("SELECT last_heartbeat FROM agents ORDER BY last_heartbeat DESC LIMIT 1");
$row2 = $stmt2->fetch();

$output = "Server Check Result:\n";
$output .= "Events in last 10 min: " . $row['count'] . "\n";
$output .= "Last Heartbeat in DB: " . ($row2['last_heartbeat'] ?? 'N/A') . "\n";
$output .= "Current DB Time: " . $pdo->query("SELECT NOW()")->fetchColumn() . "\n";

file_put_contents(__DIR__ . '/server_check.txt', $output);
echo "Check completed.";
