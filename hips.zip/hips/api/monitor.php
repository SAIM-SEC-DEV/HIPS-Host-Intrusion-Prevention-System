<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT hostname, agent_uuid, last_heartbeat, TIMESTAMPDIFF(SECOND, last_heartbeat, NOW()) as seconds_ago FROM agents ORDER BY last_heartbeat DESC LIMIT 5");
$agents = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Recent Heartbeats</h3>";
echo "<table border='1'><tr><th>Hostname</th><th>UUID</th><th>Last Heartbeat</th><th>Seconds Ago</th></tr>";
foreach ($agents as $agent) {
    echo "<tr><td>{$agent['hostname']}</td><td>{$agent['agent_uuid']}</td><td>{$agent['last_heartbeat']}</td><td>{$agent['seconds_ago']}</td></tr>";
}
echo "</table>";
echo "<br>Server Time: " . date('Y-m-d H:i:s');
