<?php
require_once __DIR__ . '/../config/db_connect.php';

$new_token = bin2hex(random_bytes(32));
$stmt = $pdo->prepare("UPDATE agents SET auth_token = :token WHERE id = 1");
if ($stmt->execute([':token' => $new_token])) {
    echo "SUCCESS: Token updated to $new_token";
    file_put_contents(__DIR__ . '/new_token.txt', $new_token);
} else {
    echo "ERROR: Failed to update token.";
}
