<?php
require_once __DIR__ . '/../config/db_connect.php';

$stmt = $pdo->query("SELECT module, event_type, severity, title, created_at FROM events ORDER BY created_at DESC LIMIT 10");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Recent Events Reported by Agents</h3>";
echo "<table border='1'><tr><th>Time</th><th>Module</th><th>Type</th><th>Severity</th><th>Title</th></tr>";
foreach ($events as $e) {
    echo "<tr><td>{$e['created_at']}</td><td>{$e['module']}</td><td>{$e['event_type']}</td><td>{$e['severity']}</td><td>{$e['title']}</td></tr>";
}
echo "</table>";
echo "<br>Current Server Time: " . date('Y-m-d H:i:s');
