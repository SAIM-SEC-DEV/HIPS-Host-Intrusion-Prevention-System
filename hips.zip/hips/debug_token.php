<?php
require_once __DIR__ . '/config/db_connect.php';

$token = 'YTAzZmI2MDg4M2UwMzM1YzhhYjFmY2I2ZTYxZjU3MzAyNDQxMjBlYTNiNjU4YTY4MjM0MjczYjE4ODBiZTc2OTkyYmJhYTc1YzEyMjA3MWMyNDU5MjE4YWQ3MDEyMmQ2NDUwYjBkM2NiNDI2MzdiZDExZDNjNjNkNGYwNmViNjY=';

$stmt = $pdo->prepare('SELECT id, hostname, agent_uuid, auth_token FROM agents');
$stmt->execute();
$agents = $stmt->fetchAll();

echo "<h1>Agent Debug</h1><pre>";
foreach ($agents as $agent) {
    echo "ID: " . $agent['id'] . "\n";
    echo "Hostname: " . $agent['hostname'] . "\n";
    echo "Agent UUID: " . $agent['agent_uuid'] . "\n";
    echo "Token match: " . ($agent['auth_token'] === $token ? "YES" : "NO") . "\n";
    echo "DB Token: " . $agent['auth_token'] . "\n";
    echo "Prop Token: " . $token . "\n";
    echo "---------------------------------\n";
}
echo "</pre>";
