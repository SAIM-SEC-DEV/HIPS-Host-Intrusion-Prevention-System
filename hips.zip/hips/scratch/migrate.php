<?php
require_once __DIR__ . '/../config/db_connect.php';

$sqlFile = __DIR__ . '/../hips_migration_v1.2_osquery.sql';
if (!file_exists($sqlFile)) {
    die("Migration SQL file not found.");
}

$sql = file_get_contents($sqlFile);

try {
    $pdo->exec($sql);
    echo "Migration successful!";
} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage();
}
?>
