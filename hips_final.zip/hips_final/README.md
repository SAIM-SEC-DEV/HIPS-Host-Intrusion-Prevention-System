# 🛡️ HIPS-OOP: Enterprise Host Intrusion Prevention System

[![Java Version](https://img.shields.io/badge/Java-21%2B-orange.svg)](https://www.oracle.com/java/)
[![PHP Version](https://img.shields.io/badge/PHP-8.2%2B-blue.svg)](https://www.php.net/)
[![Database](https://img.shields.io/badge/Database-MySQL%20%7C%20MariaDB-lightgrey.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An enterprise-grade, modular, and service-oriented Host Intrusion Prevention System (HIPS) designed to provide real-time endpoint monitoring, threat detection, and automated active response. The project employs a decoupled client-server architecture, mapping endpoint telemetry directly to the **MITRE ATT&CK** threat framework and enforcing strict security hardening controls.

---

## 🏛️ Project Architecture

HIPS-OOP is structured into two core components:
1. **Java Agent (Endpoint Client):** A lightweight, multi-threaded monitoring service written in Java. It utilizes a **Service Manager design pattern** to run independent telemetry threads (File, Network, Process, Registry, Anomaly Detection) in an asynchronous, fault-tolerant loop.
2. **Management Server (PHP Web Console):** A centralized PHP 8.2+ control panel backed by a MySQL database. It receives telemetry reports, visualizes alerts, maps events to MITRE ATT&CK techniques, and dispatches administrative actions (e.g., blocking IPs, killing processes).

```mermaid
graph TD
    subgraph "Host Machine (Endpoint)"
        A[Java Agent] --> B(Service Manager)
        B --> C[File Monitor]
        B --> D[Network Monitor]
        B --> E[Process Monitor]
        B --> F[Registry Monitor]
        B --> G[Anomaly Detector]
        B --> H[Yara Malware Scanner]
        I[(SQLite Fallback Cache)] <--> A
    end
    subgraph "Administrative Server"
        A -- HTTPS / Bearer Token --> J[REST API]
        J --> K[(MySQL Database)]
        L[Web Dashboard] <--> K
        L -- Command Queue --> J
    end
    style A fill:#1b3a6b,stroke:#fff,stroke-width:2px,color:#fff
    style L fill:#d32f2f,stroke:#fff,stroke-width:2px,color:#fff
```

---

## 🚀 Key Features

* **Decoupled Service Manager:** Eliminates monolithic failures. Individual monitoring threads operate independently with automatic exception recovery.
* **FIM (File Integrity Monitoring):** Real-time monitoring of sensitive directories using SHA-256 integrity hash verification.
* **Structured Network Telemetry:** Network connections are audited using native Windows PowerShell `Get-NetTCPConnection` parsing, bypassing fragile text command parsing.
* **MITRE ATT&CK Integration:** Alert mapping enriches telemetry events with Technique IDs (e.g., *T1543.003 - Windows Service Creation*) and Tactics.
* **Active Response Command Queue:** Administrators can remotely push commands to agents (block IPs, quarantine files, kill processes, retrieve file dumps).
* **Fault-Tolerant Cache:** A local SQLite fallback cache buffers logs if connection to the management server is temporarily lost.
* **Memory Protection:** A Least Recently Used (LRU) cache is implemented on connection trackers to prevent memory bloat and overflow conditions.
* **Security Hardening:**
  * Strict regex-based input validation on all system command hooks (preventing Command Injection).
  * Environment-variable database configuration (no hardcoded passwords).
  * Enforced administrative password changes on first boot.
  * API authentication secured via cryptographic Bearer tokens.

---

## 📂 Repository Structure

```text
├── agent/                  # Java Agent Client Source Code
│   ├── src/com/hips/agent/ # Active packages (FIM, Network, Mitre, Anomaly, etc.)
│   ├── lib/                # Third-party dependency libraries (.jar)
│   └── bin/                # Compiled .class files (ignored in Git)
├── server/                 # PHP Management Server & Dashboard
│   ├── api/                # REST API Endpoints (heartbeat, report, register, etc.)
│   ├── config/             # Database connection credentials and helpers
│   └── dashboard/          # Administration dashboard GUI frontend
├── sql/                    # SQL Database Schemas & Migrations
│   ├── schema.sql          # Primary database layout
│   └── schema_update_*.sql # Incremental upgrades (v2, v3)
├── rules/                  # Threat intelligence rules
│   └── starter_rules.yar   # YARA rules for malware scanner
├── docs/                   # Deployment guides and technical manuals
├── .gitignore              # Configures files ignored by Git tracking
├── hips-agent.properties.example # Template agent configurations
├── recompile-agent.bat     # Compile script targeting Java 21 compatibility
├── deploy-package.bat      # Package agent class files & libs into a portable 'dist' folder
└── README.md               # Project overview and introduction
```

---

## ⚙️ Getting Started

### 1. Database Setup
1. Open your database administrator (e.g., phpMyAdmin, MySQL Workbench).
2. Create a new database named `hips_db`.
3. Import the file `sql/schema.sql`.
4. (Optional) Run any incremental scripts in the `sql/` folder to apply the latest tables.

### 2. Server Configuration
1. Deploy the `server/` folder to your web server (e.g., Apache/XAMPP, Nginx).
2. Configure database credentials in `server/config/db_connect.php`. By default, it reads environment variables (`HIPS_DB_HOST`, `HIPS_DB_USER`, `HIPS_DB_PASS`, `HIPS_DB_NAME`), falling back to standard localhost defaults.
3. Access the dashboard via your browser (`http://localhost/hips/dashboard/index.php`) and register your administrator account.

### 3. Agent Deployment
1. Rename `hips-agent.properties.example` to `hips-agent.properties`.
2. Configure the server URL and your registration details:
   ```properties
   server.url=http://your-server-ip/hips
   auth.token=YOUR_ASSIGNED_AGENT_TOKEN
   agent.owner=YourName
   ```
3. To recompile and build the portable distribution, run:
   ```cmd
   recompile-agent.bat
   ```
4. This compiles the agent classes and places a portable distribution package in `dist/`. Copy the `dist` directory to your target host and start the agent using:
   ```cmd
   run-agent.bat
   ```

---

## 🛡️ License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
